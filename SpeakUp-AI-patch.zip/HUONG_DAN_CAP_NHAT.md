# SpeakUp AI – Bản sửa lỗi phản hồi chat

## Lỗi đã tìm thấy
Giao diện gửi tin nhắn đến `/api/chat`, nhưng bản mã nguồn trước đó chỉ có `api/analyze.ts`. Trên Vercel, yêu cầu chat vì thế không tới được Gemini; giao diện rơi vào câu trả lời dự phòng cố định “Hay quá! … rất hiểu ý của em rồi đấy”.

## Các thay đổi
- Bổ sung API serverless `/api/chat` để gửi câu trả lời học sinh đến Gemini và trả về lời đáp theo ngữ cảnh.
- Bổ sung `/api/best-response`, `/api/health` và `/api/benchmark/run` cho các tính năng đang được giao diện gọi.
- Dùng `gemini-3.8-flash` và `gemini-3.6-flash` làm các model thử lần lượt.
- Khi Gemini/API gặp lỗi, hiển thị thông báo rõ ràng và dùng phản hồi dự phòng theo ngữ cảnh thay vì giả vờ AI đã hiểu.
- Cải thiện phản hồi dự phòng cho tình huống xua đuổi bạn mới và tình huống xin chép bài kiểm tra.
- Cấu hình thời lượng tối đa cho Vercel Functions.

## Triển khai lên dự án hiện tại
1. Giữ nguyên biến môi trường `GEMINI_API_KEY` trong Vercel, môi trường **Production**. Không đưa giá trị key vào mã nguồn.
2. Thêm/cập nhật các tệp có trong bản sửa vào repository `thuhta10-debug/SpeakUp-AI`, nhánh `main`, rồi commit.
3. Chờ Vercel tự triển khai và báo **Ready**.
4. Mở `https://speak-up-ai-chi.vercel.app/api/health`. Kết quả mong đợi là JSON có `"status":"ok"` và `"hasGeminiKey":true`.
5. Mở website, thử gửi câu trả lời khác nhau trong cùng một tình huống. Nếu Gemini bị giới hạn quota hoặc key lỗi, giao diện sẽ hiện thông báo “Lưu ý về AI” thay vì đưa ra lời khen chung chung.

## Lưu ý kiểm thử
Đã kiểm tra cú pháp TypeScript của các tệp sửa, kiểm tra các handler với phản hồi dự phòng và xác nhận JSON của `vercel.json` hợp lệ. Chưa chạy được toàn bộ lệnh build tại môi trường chỉnh sửa này vì quá trình tải dependencies qua npm bị hết thời gian; Vercel sẽ chạy build khi có commit mới.
